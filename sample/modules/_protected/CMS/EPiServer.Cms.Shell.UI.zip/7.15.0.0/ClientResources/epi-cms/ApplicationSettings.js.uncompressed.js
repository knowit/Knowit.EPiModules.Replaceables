﻿define("epi-cms/ApplicationSettings", [],
function () {
    return {
        // summary:
        //      epi-cms/ApplicationSettings
        // description:
        //      Application settings for CMS.
        // tags:
        //      public

    };
});